package com.example.ds;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText editTextHeight, editTextWeight, editTextAge;
    private RadioGroup radioGroupGender;
    private RadioButton radioButtonMale, radioButtonFemale;
    private TextView textViewResult, textViewInterpretation;
    private Button buttonCalculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextHeight = findViewById(R.id.txtTaille);
        editTextWeight = findViewById(R.id.txtPoids);
        editTextAge = findViewById(R.id.txtAge);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        radioButtonMale = findViewById(R.id.rdbHomme);
        radioButtonFemale = findViewById(R.id.rdbFemme);
        textViewResult = findViewById(R.id.lblResultat);
        textViewInterpretation = findViewById(R.id.lblInterpretation);
        buttonCalculate = findViewById(R.id.btnCalculIMG);

        buttonCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculateIMG();
            }
        });
    }

    private void calculateIMG() {
        String strHeight = editTextHeight.getText().toString();
        String strWeight = editTextWeight.getText().toString();
        String strAge = editTextAge.getText().toString();

        if(strHeight.equals("") || strWeight.equals("") || strAge.equals("")) {
            Toast.makeText(MainActivity.this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
        } else {
            double height = Double.parseDouble(strHeight) / 100;
            double weight = Double.parseDouble(strWeight);
            int age = Integer.parseInt(strAge);

            int selectedGender = radioGroupGender.getCheckedRadioButtonId();
            double genderFactor = 0;

            if(selectedGender == R.id.radioButtonMale) {
                genderFactor = 1;
            }

            double img = 0;

            if(age <= 15) {
                img = (1.51 * (weight / (height * height))) + (0.70 * age) - (3.6 * genderFactor) + 1.4;
            } else {
                img = (1.20 * (weight / (height * height))) + (0.23 * age) - (10.8 * genderFactor) - 5.4;
            }

            textViewResult.setText(String.format("%.2f%%", img));

            if(selectedGender == R.id.radioButtonFemale) {
                if(img < 25) {
                    textViewInterpretation.setText("Trop maigre");
                } else if(img >= 25 && img <= 30) {
                    textViewInterpretation.setText("Pourcentage normal");
                } else {
                    textViewInterpretation.setText("Trop de graisse");
                }
            } else {
                if(img < 15) {
                    textViewInterpretation.setText("Trop maigre");
                } else if(img >= 15 && img <= 20) {
                    textViewInterpretation.setText("Pourcentage normal");
                } else {
                    textViewInterpretation.setText("Trop de graisse");
                }
            }
        }
    }
}
